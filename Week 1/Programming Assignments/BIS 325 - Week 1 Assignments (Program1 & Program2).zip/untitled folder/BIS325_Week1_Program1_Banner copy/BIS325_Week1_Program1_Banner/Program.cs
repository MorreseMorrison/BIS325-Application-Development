﻿//Name: Morrese Morrison
//University: Peirce College
//Professor: Michael Chu
//Assignment: Program 1 Banner
//Date: 3/25/2023 1:00PM
//Completed Date: 2:30PM
/*Program Purpose: This Program prints a banner of internal documentation as
 well as my information*/
using System;

namespace BIS325_Week1_Program1_Banner
{
    class Program
    {
        static void Main(string[] args)

        {
            Console.WriteLine("*********************************************************");
            Console.WriteLine("**   Programming Assignment #1                        **");
            Console.WriteLine("**   Developer: Morrese Morrison                      **");
            Console.WriteLine("**   Date Submitted: March 25th 2023                  **");
            Console.WriteLine("**   Purpose: To Provide internal documentation,      **" +
                            "\n**   regarding this application                       **");
            Console.WriteLine("*********************************************************");
        }
    }
}
